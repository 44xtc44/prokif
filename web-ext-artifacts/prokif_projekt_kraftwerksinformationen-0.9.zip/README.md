# PROKIF - Projekt Kraftwerksinformationen

## Overview

This repository shows the source code of a browser add-on.
Runs on FireFox.

Mozilla Add-on: https://addons.mozilla.org/en-US/firefox/addon/prokif/

ReadTheDocs  (code doc): https://prokif.readthedocs.io/en/latest/README.html

# Why


# How it works


# HowTo PC

Clone the repo. 

FireFox 'about:debugging', and 'this FireFox' select a new temporary Add-on.

Open the manifest.json in the cloned folder and then start the Add-on from the puzzle icon list.

# HowTo Android

Clone the repo. 

Install 'web-ext' "https://extensionworkshop.com/documentation/develop/developing-extensions-for-firefox-for-android/".

Install Android Studio latest and create a dummy project. The device manager is needed to run a Android Virtual Device (AVD).

You then want to download the FireFox apk file and drag it onto the AVD. 
Search "Firefox Nightly for Developers". If you find 'APKmirror' save, go there. Else use the registration
process to enable PlayStore to pull FireFox Nightly, into every AVD.


> **_NOTE:_** Deinstall FireFox 'regular' version, if any.

Open a terminal in the root of the repo clone, to load the Add-on into the AVD via USB.

    @PlaylistBooster$ adb devices -l
    List of devices attached
    emulator-5554   offline

    @PlaylistBooster$ web-ext run --target=firefox-android --android-device emulator-5554 --firefox-apk org.mozilla.fenix

The AVD and FireFox Nightly must be USB enabled (Dev mode) then.

Drag some media files into 'Device Explorer' in 'Android Studio'. Use 'mnt/sdcard/Music', to see it in user view on AVD.

# Known issues



# Contributions

Pull requests are welcome.
If you want to make a major change, open an issue first to have a short discuss.


# Thank you


# License

Apache 2.0 License