PROKIF - Projekt Kraftwerksinformationen
=========================================

Overview
---------
This repository shows the source code of a ternary plot diagram software.
It can be used to analyse data from energy production in Europe.

Node.js module: https://www.npmjs.com/package/prokif

Mozilla Add-on: https://addons.mozilla.org/en-US/firefox/addon/prokif/

ReadTheDocs  (code doc): https://prokif.readthedocs.io/en/latest/README.html

Why
---

A YouTube video showed a ternary plot diagram to explain energy production in Germany.

How it works
-------------



HowTo PC
--------
Clone the repo. 

FireFox 'about:debugging', and 'this FireFox' select a new temporary Add-on.

Open the PlaylistBooster manifest.json and then start the Add-on from the puzzle icon list.

HowTo Android
--------------
Clone the repo. 

Install 'web-ext' "https://extensionworkshop.com/documentation/develop/developing-extensions-for-firefox-for-android/".

Install Android Studio latest and create a dummy project. The device manager is needed to run a Android Virtual Device (AVD).

You then want to download the FireFox apk file and drag it onto the AVD. 
Search "Firefox Nightly for Developers". If you find 'APKmirror' save, go there. Else use the registration
process to enable PlayStore to pull FireFox Nightly, into every AVD.

.. note::
    Deinstall FireFox 'regular' version, if any.

Open a terminal in the root of the repo clone, to load the Add-on into the AVD via USB.

.. code-block:: console

    @PlaylistBooster$ adb devices -l
    List of devices attached
    emulator-5554   offline

    @PlaylistBooster$ web-ext run --target=firefox-android --android-device emulator-5554 --firefox-apk org.mozilla.fenix

The AVD and FireFox Nightly must be USB enabled (Dev mode) then.


Drag some media files into 'Device Explorer' in 'Android Studio'. Use 'mnt/sdcard/Music', to see it in user view on AVD.

.. image:: ./start.png
            :alt: start screen
            :class: with-border
            :height: 585

-

.. image:: ./sound.png
            :alt: sound files active
            :class: with-border
            :height: 585

-

.. image:: ./video.png
            :alt: video files active
            :class: with-border
            :height: 585


Gain - preamp
--------------
Bring your earbuds to the limit.
Push the preamp to 500%. This feels like 20% louder.

Works with bluetooth headphones!

Known issues
-------------
FireFox for Android looses file collection object  
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
(A) FF video element 
will stop playing at all, if the PlaylistBooster tab is in the 
background and you want to bring it to the foreground.

(B) FF video element
will stop playing if the PlaylistBooster tab is in the 
background and you open another website.

Temporary solution: Press app reload button.

FireFox for Android Add-on not visible (DEV)  
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
FireFox Nightly MUST have an open tab (i.e wikipedia) 
before you can see/click the ( <temporay> web-ext ) Add-on in the Extension bar.

Contributions
-------------

Pull requests are welcome.
If you want to make a major change, open an issue first to have a short discuss.


Thank you
----------
`YouTube franks laboratory <https://www.youtube.com/results?search_query=franks+laboratory>`_

License
-------
Apache 2.0 License